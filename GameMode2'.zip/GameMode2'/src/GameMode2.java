import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import static javafx.application.Platform.exit;


public class GameMode2  implements EventHandler<ActionEvent>{
    public ColorButton red=new ColorButton("red");
    public ColorButton blue=new ColorButton("blue");
    public ColorButton green=new ColorButton("green");
    public ColorButton yellow=new ColorButton("yellow");
    public ColorButton pink=new ColorButton("pink");
    public ColorButton turquoise=new ColorButton("turquoise");
    public ColorButton coral=new ColorButton("coral");
    public ColorButton cyan=new ColorButton("cyan");
    public ColorButton purple=new ColorButton("purple");
    public ColorButton lime=new ColorButton("lime");
    public ColorButton brown=new ColorButton("brown");
    public ColorButton gray = new ColorButton("gray");

    public Timer timer = new Timer();



    public int[][] matrix=new int[0][0]; //adj_matrix
    public Pane layout=new Pane();  //Pane for GraphColor Scene
    public Pane root; //Pane for Input Scene

    public Text invalid_c=new Text(); //
    public Text status_submit=new Text();
    public Text time_done=new Text();
    public Text resulting_number=new Text();
    public Text exact_number_text=new Text();
    public Text time_left=new Text();

    public Button new_color=new Button();
    public Button submit_button=new Button();
    public Button quit_button=new Button();
    public Random rand=new Random();
    public Button[] button_list;
    public Line[] color_lineList;

    public Line line=new Line();
    public int time_frame;
    public int count;

    public int choice;
    public int newc_counter=0;
    public boolean fixerForSubmitB=true;
    public static String[] style_list= new String[12];
    public static String[] list_holder= new String[12];
    public Button v_button;
    public TextField v_textField;
    TextField e_textField;
    TextField time_field;
    int numberOfVertices;
    int numberOfEdges;
    Ellipse button_shape=new Ellipse(10,10);



    public Scene scene1,scene2;
    Stage window;
    public GameMode2(Stage someStage, Pane root1,Button someVbutton,TextField someVtextField,TextField someEtextField
    ,TextField timer_field) {
        this.window = someStage;
        this.root = root1;
        numberOfVertices = 1;
        numberOfEdges= 2;
        time_frame=0;
        this.v_button=someVbutton;
        v_button.setOnAction(this);
        this.v_textField=someVtextField;
        this.e_textField=someEtextField;
        this.time_field=timer_field;

    }

    public  void run() {


        window.setTitle("GRAPH_COLOR_TEST");
        layout.setStyle("-fx-background-color: beige;");
        scene1 = new Scene(root, 1050, 600);
        scene2 = new Scene(layout, 1200, 800);
        window.setScene(scene1);

    }
    public void setup_timer(Stage primaryStage) {
        try {
            layout.getChildren().add(timer);
            timer.setLayoutX(layout.getWidth()-150);
            timer.setLayoutY(60);
            timer.setFont(Font.font("TimesRoman", FontWeight.BOLD, 24));

            timer.start();
            if(System.currentTimeMillis()==10000){timer.stop();}
            System.out.println("CURRENT TIME"+System.currentTimeMillis());

        } catch(Exception e) {
            e.printStackTrace();
        }

    }

    public Scene time_out(){
        boolean value=false;
        Pane end_layout=new Pane();

        end_layout.setPrefSize(1200,800);
        check_completion();
      long time_when_stop=(time_frame-(timer.getTime()))/1000;

        for (int i = 0; i < matrix.length; i++) {
            if (button_list[i].getStyle().equals("-fx-background-color: white;")) {
                resulting_number.setText("You haven't been able to complete the graph :((");
                end_layout.setStyle("-fx-background-color: salmon;");
                time_left.setText("YOUR TIME FRAME : "+ (time_frame/1000)+ " seconds");
                break;
            }else{
                end_layout.setStyle("-fx-background-color: teal;");
                time_done.setText("THE GRAPH WAS COMPLETED");
                resulting_number.setText("YOUR CHROMATIC NUMBER: " + count);
                time_left.setText("You had : "+time_when_stop+ " seconds left");
            }
            }
        end_layout.getChildren().add(time_left);
        end_layout.getChildren().add(exact_number_text);
        end_layout.getChildren().add(time_done);
        end_layout.getChildren().add(resulting_number);
        end_layout.getChildren().add(quit_button);


        Scene end_scene=new Scene(end_layout);

        return end_scene;

    }





    @Override
    public void handle(ActionEvent actionEvent) {


        if (actionEvent.getSource() == v_button) {
            numberOfVertices = Integer.parseInt(v_textField.getText());
            numberOfEdges = Integer.parseInt(e_textField.getText());
            time_frame = Integer.parseInt(time_field.getText()) * 1000;

            timer = new Timer(time_frame);


            Button[] buttonList_holder = new Button[numberOfVertices];
            Line[] lineList_holder = new Line[numberOfEdges];

            button_list = buttonList_holder;
            color_lineList = lineList_holder;


            root.getChildren().remove(scene1);
            matrix = createMatrix();
            setupButtonList(numberOfVertices);
            setupEdges(matrix);
            setupButtons();
            window.setScene(scene2);
            setup_timer(window);
        }
        if (!timer.getProccessing() && !layout.getChildren().contains(time_done)) {
            window.setScene(time_out());
        }

        helperButtons();
        setOnAction();
        for (int i = 0; i < matrix.length; i++) {
            if (actionEvent.getSource() == button_list[i]) {
                add();
                colorLines(matrix, i);
                choice = i;

            }
        }
        if (actionEvent.getSource() == red) {
            button_list[choice].setStyle(red.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == blue) {
            button_list[choice].setStyle(blue.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == green) {
            button_list[choice].setStyle(green.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == yellow) {
            button_list[choice].setStyle(yellow.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == pink) {
            button_list[choice].setStyle(pink.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == turquoise) {
            button_list[choice].setStyle(turquoise.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == brown) {
            button_list[choice].setStyle(brown.getStyle());
            check_adj();
            remove();
        }else if (actionEvent.getSource() == cyan) {
            button_list[choice].setStyle(cyan.getStyle());
            check_adj();
            remove();
        }else if (actionEvent.getSource() == purple) {
            button_list[choice].setStyle(purple.getStyle());
            check_adj();
            remove();
        }else if (actionEvent.getSource() == gray) {
            button_list[choice].setStyle(gray.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == coral) {
            button_list[choice].setStyle(coral.getStyle());
            check_adj();
            remove();
        } else if (actionEvent.getSource() == lime) {
            button_list[choice].setStyle(lime.getStyle());
            check_adj();
            remove();
        }    else if (actionEvent.getSource() == new_color) {
            newc_counter++;
            colorCounter();
        } else if (actionEvent.getSource() == quit_button) {
            exit();
        } else if (actionEvent.getSource() == submit_button) {
            style_list = list_holder;
            window.setScene(time_out());

        }
    }


    public void colorCounter() {
        if (newc_counter == 1) layout.getChildren().add(yellow);
        if (newc_counter == 2) layout.getChildren().add(pink);
        if (newc_counter == 3) layout.getChildren().add(turquoise);
        if (newc_counter == 4) layout.getChildren().add(lime);
        if (newc_counter == 5) layout.getChildren().add(brown);
        if (newc_counter == 6) layout.getChildren().add(gray);
        if (newc_counter == 7) layout.getChildren().add(coral);
        if (newc_counter == 8) layout.getChildren().add(cyan);
        if (newc_counter == 9) layout.getChildren().add(purple);
    }

    public void remove() {

        layout.getChildren().remove(red);
        layout.getChildren().remove(blue);
        layout.getChildren().remove(green);
        layout.getChildren().remove(yellow);
        layout.getChildren().remove(new_color);
        layout.getChildren().remove(pink);
        layout.getChildren().remove(turquoise);
        layout.getChildren().remove(status_submit);
        layout.getChildren().remove(lime);
        layout.getChildren().remove(brown);
        layout.getChildren().remove(gray);
        layout.getChildren().remove(coral);
        layout.getChildren().remove(cyan);
        layout.getChildren().remove(purple);

        for (Line value : color_lineList) {
            layout.getChildren().remove(value);
        }
    }

    public void add() {

        layout.getChildren().add(new_color);
        layout.getChildren().add(red);
        layout.getChildren().add(blue);
        layout.getChildren().add(green);

        if(fixerForSubmitB) {
            layout.getChildren().add(submit_button);
            layout.getChildren().add(quit_button);
            new_color.setOnAction(this);
            submit_button.setOnAction(this);
            quit_button.setOnAction(this);
        }
        if (newc_counter >= 1) layout.getChildren().add(yellow);
        if (newc_counter >= 2) layout.getChildren().add(pink);
        if (newc_counter >= 3) layout.getChildren().add(turquoise);
        if (newc_counter >= 4) layout.getChildren().add(lime);
        if (newc_counter >= 5) layout.getChildren().add(brown);
        if (newc_counter >= 6) layout.getChildren().add(gray);
        if (newc_counter >= 7) layout.getChildren().add(coral);
        if (newc_counter >= 8) layout.getChildren().add(cyan);
        if (newc_counter >= 9) layout.getChildren().add(purple);
        fixerForSubmitB=false;
    }

    public void check_adj() {
        for (int j = 0; j < matrix[choice].length; j++) {
            if ((matrix[choice][j] == 1 || matrix[j][choice] == 1) && (button_list[j].getStyle().equals(button_list[choice].getStyle())) && choice != j) {
                button_list[choice].setStyle("-fx-background-color: white;");
                layout.getChildren().add(invalid_c);
                break;
            } else
                layout.getChildren().remove(invalid_c);
        }
    }

    public void helperButtons() {
        time_left.setLayoutX(100);
        time_left.setLayoutY(400);
        time_left.setFont(Font.font("TimesRoman", FontWeight.SEMI_BOLD, 24));

        resulting_number.setLayoutX(100);
        resulting_number.setLayoutY(200);
        resulting_number.setFont(Font.font("TimesRoman", FontWeight.BOLD, 28));

        exact_number_text.setLayoutX(100);
        exact_number_text.setLayoutY(300);
        exact_number_text.setFont(Font.font("TimesRoman", FontWeight.BOLD, 28));
        exact_number_text.setText("THE ACTUAL NUMBER IS: ?");

        time_done.setLayoutX(100);
        time_done.setLayoutY(100);
        time_done.setFont(Font.font("TimesRoman", FontWeight.BOLD, 32));
        time_done.setText("TIME HAS RUN OUT");


        invalid_c.setLayoutX(200);
        invalid_c.setLayoutY(30);
        invalid_c.setText("Cannot use that color \n Please choose another");
        invalid_c.setFont(Font.font("TimesRoman", FontWeight.BOLD, 14));

        status_submit.setLayoutX(400);
        status_submit.setLayoutY(30);
        status_submit.setFont(Font.font("TimesRoman", FontWeight.BOLD, 14));

        new_color.setText("Set a new color");
        new_color.setLayoutX(layout.getWidth()-300);
        new_color.setLayoutY(20);

        submit_button.setLayoutX(layout.getWidth()-150);
        submit_button.setLayoutY(20);
        submit_button.setText("Submit Answer");

        quit_button.setLayoutX(layout.getWidth()-100);
        quit_button.setLayoutY(700);
        quit_button.setText("Quit");
    }

    public void setupButtonList(int numberOfVertices) {
        for (int i = 0; i < numberOfVertices; i++) {
            button_list[i] = new Button();

            int max_bound =(int) layout.getHeight()-100;
            int min_bound = 100;
            int j = 0;
            boolean buttons_close = false;
            double X_coordinate=0;
            double Y_coordinate=0;
            while (j < numberOfVertices) {
                System.out.println("LAYOUT WIDTH: "+layout.getWidth());
                X_coordinate = rand.nextInt((int) (((layout.getWidth()-100))));
                Y_coordinate = ThreadLocalRandom.current().nextInt(min_bound, max_bound + 1);
                if (button_list[j] == null) {
                    break;
                }
                buttons_close = false;
                final int distance=30;
                boolean close_x = (X_coordinate - button_list[j].getLayoutX() < distance && X_coordinate>button_list[j].getLayoutX())
                        || (button_list[j].getLayoutX() - X_coordinate < distance && button_list[j].getLayoutX()>X_coordinate);
                boolean close_y = (Y_coordinate - button_list[j].getLayoutY() < distance && Y_coordinate>button_list[j].getLayoutY())
                        || (button_list[j].getLayoutY() - Y_coordinate < distance && button_list[j].getLayoutY()>Y_coordinate);
                if (close_x && close_y) {
                    buttons_close = true;
                    System.out.println("CHANGED LAYOUT");
                }
                j++;
            }
            if(button_list[i]==null)
            {
                break;
            }
            if (buttons_close)
            {
                X_coordinate += 20;
                Y_coordinate += 20;
                button_list[i].setLayoutX(X_coordinate);
                button_list[i].setLayoutY(Y_coordinate);
            }
            button_list[i].setShape(button_shape);
            button_list[i].setLayoutX(X_coordinate);
            button_list[i].setLayoutY(Y_coordinate);
            button_list[i].setText(Integer.toString(i));
            button_list[i].setStyle("-fx-background-color: white;");
            layout.getChildren().add(button_list[i]);
            button_list[i].setOnAction(this); //for gm3 w/out this
        }
    }

    public void setupEdges(int[][] adj_matrix) {
        String[] edged_buttons=new String[numberOfEdges*2];
        int counterOfedged=0;
        for (int i = 0; i < adj_matrix.length; i++) {
            System.out.println();
            for (int j = 0; j < adj_matrix.length; j++) {
                System.out.print(adj_matrix[i][j] + "  ");
                if (adj_matrix[i][j] == 1) {
                    boolean val=false;
                    //System.out.println("CREATED NEW LINE FROM Y: "+button_list[i].getLayoutY()+10+" TO Y: "+button_list[j].getLayoutY()+10);
                    line = new Line();


                    edged_buttons[counterOfedged]= button_list[i].getText() + button_list[j].getText();
                    //System.out.println("Edged Buttons: "+edged_buttons[counterOfedged]);
                    //System.out.println("First Edged Buttons: "+edged_buttons[0]);
                    for(int k=0;k<=counterOfedged;k++)
                    {
                        if(edged_buttons[k].startsWith(String.valueOf(button_list[j].getText()))
                                && edged_buttons[k].endsWith(String.valueOf(button_list[i].getText())))
                        {
                            // System.out.println("WAS HERE");
                            val=true;
                        }

                    }
                    counterOfedged++;
                    if(val) {continue;}

                    line.setStartX(button_list[i].getLayoutX()+10);
                    line.setStartY(button_list[i].getLayoutY()+10);
                    line.setEndY(button_list[j].getLayoutY()+10);
                    line.setEndX(button_list[j].getLayoutX()+10);
                    layout.getChildren().add(line);
                    //System.out.println("CREATED NEW LINE FROM BUTTON: "+button_list[i].getText() +  " TO BUTTON: "+button_list[j].getText());

                }
            }

        }
    }
    public void setupButtons() {
        red.setup(red);
        blue.setup(blue);
        green.setup(green);
        yellow.setup(yellow);
        pink.setup(pink);
        turquoise.setup(turquoise);
        lime.setup(lime);
        brown.setup(brown);
        gray.setup(gray);
        coral.setup(coral);
        cyan.setup(cyan);
        purple.setup(purple);

    }

    public void setOnAction() {
        red.setOnAction(this);
        blue.setOnAction(this);
        green.setOnAction(this);
        yellow.setOnAction(this);
        pink.setOnAction(this);
        turquoise.setOnAction(this);
        lime.setOnAction(this);
        brown.setOnAction(this);
        purple.setOnAction(this);
        coral.setOnAction(this);
        cyan.setOnAction(this);
        gray.setOnAction(this);
    }

    public int[][] createMatrix()
    {

        int[][] adj_matrix = new int[numberOfVertices][numberOfVertices];
        int counterOfEdges = 0;
        while (counterOfEdges < numberOfEdges) {
            int n = rand.nextInt(numberOfVertices);
            int m = rand.nextInt(numberOfVertices);

            while(adj_matrix[n][m]==1) {
                n = rand.nextInt(numberOfVertices);
                m = rand.nextInt(numberOfVertices);
            }
            if(m!=n) {

                adj_matrix[n][m] = 1;
                adj_matrix[m][n] = 1;
            }else counterOfEdges--;
            counterOfEdges++;
        }
        return adj_matrix;
    }

    public void colorLines(int [][] adj_matrix,int i) {

        int counter = 0;
        for (int j = 0; j < adj_matrix.length; j++) {
            if ((adj_matrix[i][j] == 1 || adj_matrix[j][i] == 1) && i != j) {
                line = new Line();
                line.setStartX(button_list[i].getLayoutX() + 11);
                line.setStartY(button_list[i].getLayoutY() + 11);
                line.setEndY(button_list[j].getLayoutY() + 11);
                line.setEndX(button_list[j].getLayoutX() + 11);
                if (button_list[i].getStyle().equals("-fx-background-color: white;"))
                {
                    line.setStyle("-fx-stroke-width: 3;-fx-stroke: black;");
                } else {
                    String line_style=button_list[i].getStyle().substring(21);
                    line.setStyle("-fx-stroke-width: 3;-fx-stroke:"+line_style);
                }
                layout.getChildren().add(line);
                color_lineList[counter] = line;
                counter++;
            }
        }
    }

    public String[] remove_element(String[] List,int index) {
        String[] augmented_List=new String[List.length-1];
        for(int i=0,k=0;i<List.length;i++)
        {
            if(i==index)
            {
                continue;
            }
            augmented_List[k++]=List[i];
        }
        System.out.println(index+".STYLE LIST REMOVED"+style_list[index]);
        return augmented_List;
    }

    public boolean check_completion() {

        boolean value = true;
        String[] unaltered_list=new String[style_list.length];
        for (int i = 0; i < matrix.length; i++)
        {
            if (button_list[i].getStyle().equals("-fx-background-color: white;"))
            {
                return false;
            }
        }
        if (value)
        {
            for (int i = 0; i < matrix.length; i++)
            {
                for (int j = 0; j < style_list.length; j++)
                {
                    unaltered_list[j]=style_list[j];
                    if (button_list[i].getStyle().equals(style_list[j]))
                    {
                        style_list=remove_element(style_list,j);
                      if(count<7) {
                          count++;
                          System.out.println("COUNT : " + count);
                      }
                      }
                }
            }
            if(count==3) { return true;}
            style_list=unaltered_list;
        }
        return false;
    }
    public void setDisable(Button[] button_list){

        for (Button button : button_list) {
            button.setDisable(true);
        }

    }



}
