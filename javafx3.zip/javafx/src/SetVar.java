import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.Main;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class SetVar implements EventHandler<ActionEvent>{
    static public Button v_button;
   static public Button e_button;
   static public TextField v_textField;
    static TextField e_textField;
    static  Pane root=new Pane();
   static Scene scene;
    private    Parent createContent() {


        root.setPrefSize(1200, 800);

        v_textField = new TextField();
        v_textField.setText("...");
        Text v_text = new Text("Input vertix number: ");

        v_textField = new TextField();
        v_textField.setText("");

        v_button = new Button("Submit");

        Text e_text = new Text("Input edges number: ");



        e_textField = new TextField();
        e_textField.setText("...");
        Text text = new Text("Input vertices number: ");


        e_textField = new TextField();
        e_textField.setText("");




        setCoords(v_textField,v_button,v_text,e_textField,e_text);

        Image background=new Image("file:background2.jpg");
        ImageView backgroundView=new ImageView(background);
        backgroundView.setFitHeight(1200);
        backgroundView.setFitWidth(1200);
        root.getChildren().addAll(backgroundView,v_textField,v_button,v_text);
        root.getChildren().addAll(e_text,e_textField);

        return root;
    }

    public static int numberOfVertices;
    public static int numberOfEdges;

    public  int[] displayInputBox()
    {
        Stage window=new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle("Input Parameters");
        Scene scene=new Scene(createContent(),1200,800);

        int[] array={1,2};

        return array;
    }
    public  void setCoords(TextField v_textField,Button v_button,Text v_text,
                          TextField e_textField,Text e_text)
    {
        v_textField.setLayoutX(100);
        v_textField.setLayoutY(100);

        v_button.setLayoutX(270);
        v_button.setLayoutY(150);
        v_button.setOnAction(this);

        v_text.setLayoutX(100);
        v_text.setLayoutY(90);

        e_textField.setLayoutX(100);
        e_textField.setLayoutY(200);



        e_text.setLayoutX(100);
        e_text.setLayoutY(190);
    }


    @Override
    public void handle(ActionEvent actionEvent) {

    }
}
