package sample;

public class Controller {


    int w=5;
}
