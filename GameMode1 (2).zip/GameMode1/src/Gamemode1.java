import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import static javafx.application.Platform.exit;


public class Gamemode1  implements EventHandler<ActionEvent>{
    public ColorButton red=new ColorButton("red");
    public ColorButton blue=new ColorButton("blue");
    public ColorButton green=new ColorButton("green");
    public ColorButton yellow=new ColorButton("yellow");
    public ColorButton pink=new ColorButton("pink");
    public ColorButton turquoise=new ColorButton("turquoise");




    public int[][] matrix=new int[0][0]; //adj_matrix
    public Pane layout=new Pane();  //Pane for GraphColor Scene
    public Pane root; //Pane for Input Scene
    public Text invalid_c=new Text(); //
    public Text status_submit=new Text();
    public Button new_color=new Button();
    public Button submit_button=new Button();
    public Button quit_button=new Button();
    public Random rand=new Random();
    public Button[] button_list;
    public Line[] color_lineList;

    public Line line=new Line();

    public int choice;
    public int newc_counter=0;
    public boolean fixerForSubmitB=true;
    public static String[] style_list= new String[6];
    public static String[] list_holder= new String[6];
    public Button v_button;
    public TextField v_textField;
    TextField e_textField;
    int numberOfVertices;
    int numberOfEdges;
    Ellipse button_shape=new Ellipse(10,10);



    public Scene scene1,scene2;
    Stage window;
    public Gamemode1(Stage someStage, Pane root1,Button someVbutton,TextField someVtextField,TextField someEtextField) {
        this.window = someStage;
        this.root = root1;
        numberOfVertices = 1;
        numberOfEdges= 2;
        this.v_button=someVbutton;
        v_button.setOnAction(this);
        this.v_textField=someVtextField;
        this.e_textField=someEtextField;
    }

    public  void run() {
        System.out.println("FUCKYOU");
        window.setTitle("GRAPH_COLOR_TEST");
        layout.setStyle("-fx-background-color: beige;");
        scene1 = new Scene(root, 1050, 600);
        scene2 = new Scene(layout, 1200, 800);
        window.setScene(scene1);
        System.out.println("FUCK OFF");

    }
    @Override
    public void handle(ActionEvent actionEvent) {

        if (actionEvent.getSource() == v_button) {
            System.out.println("PRESSED V_BUTTON");
            numberOfVertices = Integer.parseInt(v_textField.getText());
            numberOfEdges = Integer.parseInt(e_textField.getText());
            Button[] buttonList_holder=new Button[numberOfVertices];
            Line[] lineList_holder=new Line[numberOfEdges];

            button_list=buttonList_holder;
            color_lineList=lineList_holder;


            root.getChildren().remove(scene1);
            matrix = createMatrix();
            setupButtonList(numberOfVertices);
            setupEdges(matrix);
            setupButtons();
            window.setScene(scene2);
        }
        helperButtons();
        setOnAction();
        for (int i = 0; i < matrix.length; i++) {
            if (actionEvent.getSource() == button_list[i]) {
                    add();
                colorLines(matrix, i);
                choice = i;

            }
        }
        if (actionEvent.getSource() == red) {
            button_list[choice].setStyle(red.getStyle());
            check_adj();
            remove();
        }
        else if (actionEvent.getSource() == blue) {
            button_list[choice].setStyle(blue.getStyle());
            check_adj();
            remove();
        }
        else if (actionEvent.getSource() == green) {
            button_list[choice].setStyle(green.getStyle());
            check_adj();
            remove();
        }
        else if (actionEvent.getSource() == yellow) {
            button_list[choice].setStyle(yellow.getStyle());
            check_adj();
            remove();
        }
        else if (actionEvent.getSource() == pink) {
            button_list[choice].setStyle(pink.getStyle());
            check_adj();
            remove();
        }
        else if (actionEvent.getSource() == turquoise) {
            button_list[choice].setStyle(turquoise.getStyle());
            check_adj();
            remove();
        }
        else if (actionEvent.getSource() == new_color) {
            newc_counter++;
            colorCounter();
        }
        else if (actionEvent.getSource() == quit_button) {
            exit();
        }
        else if (actionEvent.getSource() == submit_button) {
            style_list = list_holder;
            boolean value = true;
            for (int i = 0; i < matrix.length; i++) {
                if (button_list[i].getStyle().equals("-fx-background-color: white;")) {
                    value = false;

                }
            }
            if (value) {
                if (check_completion()) {
                    status_submit.setText("CONGRATULATIONS \n Answer is correct!");
                    layout.getChildren().add(status_submit);
                } else if (!check_completion()) {
                    status_submit.setText("You do not have the exact number");
                    layout.getChildren().add(status_submit);
                }
            } else{
                status_submit.setText("Please fill all the graph");
                layout.getChildren().add(status_submit);
            }
        }
    }

    public void colorCounter() {
        if (newc_counter == 1) layout.getChildren().add(yellow);
        if (newc_counter == 2) layout.getChildren().add(pink);
        if (newc_counter == 3) layout.getChildren().add(turquoise);
    }

    public void remove() {

        layout.getChildren().remove(red);
        layout.getChildren().remove(blue);
        layout.getChildren().remove(green);
        layout.getChildren().remove(yellow);
        layout.getChildren().remove(new_color);
        layout.getChildren().remove(pink);
        layout.getChildren().remove(turquoise);
        layout.getChildren().remove(status_submit);

        for (Line value : color_lineList) {
            layout.getChildren().remove(value);
        }
    }

    public void add() {

        layout.getChildren().add(new_color);
        layout.getChildren().add(red);
        layout.getChildren().add(blue);
        layout.getChildren().add(green);

        if(fixerForSubmitB) {
            layout.getChildren().add(submit_button);
            layout.getChildren().add(quit_button);
            new_color.setOnAction(this);
            submit_button.setOnAction(this);
            quit_button.setOnAction(this);
        }
        if (newc_counter >= 1) layout.getChildren().add(yellow);
        if (newc_counter >= 2) layout.getChildren().add(pink);
        if (newc_counter >= 3) layout.getChildren().add(turquoise);
        fixerForSubmitB=false;
    }

    public void check_adj() {
        for (int j = 0; j < matrix[choice].length; j++) {
            if ((matrix[choice][j] == 1 || matrix[j][choice] == 1) && (button_list[j].getStyle().equals(button_list[choice].getStyle())) && choice != j) {
                button_list[choice].setStyle("-fx-background-color: white;");
                layout.getChildren().add(invalid_c);
                break;
            } else
                layout.getChildren().remove(invalid_c);
        }
    }

    public void helperButtons() {

        invalid_c.setLayoutX(200);
        invalid_c.setLayoutY(30);
        invalid_c.setText("Cannot use that color \n Please choose another");
        invalid_c.setFont(Font.font("TimesRoman", FontWeight.BOLD, 14));

        status_submit.setLayoutX(400);
        status_submit.setLayoutY(30);
        status_submit.setFont(Font.font("TimesRoman", FontWeight.BOLD, 14));

        new_color.setText("Set a new color");
        new_color.setLayoutX(layout.getWidth()-300);
        new_color.setLayoutY(20);

        submit_button.setLayoutX(layout.getWidth()-150);
        submit_button.setLayoutY(20);
        submit_button.setText("Submit Answer");

        quit_button.setLayoutX(layout.getWidth()-100);
        quit_button.setLayoutY(700);
        quit_button.setText("Quit");
    }

    public void setupButtonList(int numberOfVertices) {
        for (int i = 0; i < numberOfVertices; i++) {
            button_list[i] = new Button();

            int max_bound =(int) layout.getHeight()-100;
            int min_bound = 100;
            int j = 0;
            boolean buttons_close = false;
            double X_coordinate=0;
            double Y_coordinate=0;
            while (j < numberOfVertices) {
                System.out.println("LAYOUT WIDTH: "+layout.getWidth());
                X_coordinate = rand.nextInt((int) (((layout.getWidth()-100))));
                Y_coordinate = ThreadLocalRandom.current().nextInt(min_bound, max_bound + 1);
                if (button_list[j] == null) {
                    break;
                }
                buttons_close = false;
                final int distance=30;
                boolean close_x = (X_coordinate - button_list[j].getLayoutX() < distance && X_coordinate>button_list[j].getLayoutX())
                        || (button_list[j].getLayoutX() - X_coordinate < distance && button_list[j].getLayoutX()>X_coordinate);
                boolean close_y = (Y_coordinate - button_list[j].getLayoutY() < distance && Y_coordinate>button_list[j].getLayoutY())
                        || (button_list[j].getLayoutY() - Y_coordinate < distance && button_list[j].getLayoutY()>Y_coordinate);
                if (close_x && close_y) {
                    buttons_close = true;
                    System.out.println("CHANGED LAYOUT");
                }
                j++;
            }
            if(button_list[i]==null)
            {
                break;
            }
            if (buttons_close)
            {
                X_coordinate += 20;
                Y_coordinate += 20;
                button_list[i].setLayoutX(X_coordinate);
                button_list[i].setLayoutY(Y_coordinate);
            }
            button_list[i].setShape(button_shape);
            button_list[i].setLayoutX(X_coordinate);
            button_list[i].setLayoutY(Y_coordinate);
            button_list[i].setText(Integer.toString(i));
            button_list[i].setStyle("-fx-background-color: white;");
            layout.getChildren().add(button_list[i]);
            button_list[i].setOnAction(this); //for gm3 w/out this
        }
    }

    public void setupEdges(int[][] adj_matrix) {
            String[] edged_buttons=new String[numberOfEdges*2];
            int counterOfedged=0;
        for (int i = 0; i < adj_matrix.length; i++) {
            System.out.println();
            for (int j = 0; j < adj_matrix.length; j++) {
               System.out.print(adj_matrix[i][j] + "  ");
                if (adj_matrix[i][j] == 1) {
                    boolean val=false;
                   //System.out.println("CREATED NEW LINE FROM Y: "+button_list[i].getLayoutY()+10+" TO Y: "+button_list[j].getLayoutY()+10);
                    line = new Line();


                    edged_buttons[counterOfedged]= button_list[i].getText() + button_list[j].getText();
                    //System.out.println("Edged Buttons: "+edged_buttons[counterOfedged]);
                    //System.out.println("First Edged Buttons: "+edged_buttons[0]);
                    for(int k=0;k<=counterOfedged;k++)
                    {
                      if(edged_buttons[k].startsWith(String.valueOf(button_list[j].getText()))
                                && edged_buttons[k].endsWith(String.valueOf(button_list[i].getText())))
                    {
                         // System.out.println("WAS HERE");
                          val=true;
                      }

                    }
                        counterOfedged++;
                    if(val) {continue;}

                    line.setStartX(button_list[i].getLayoutX()+10);
                    line.setStartY(button_list[i].getLayoutY()+10);
                    line.setEndY(button_list[j].getLayoutY()+10);
                    line.setEndX(button_list[j].getLayoutX()+10);
                    layout.getChildren().add(line);
                    //System.out.println("CREATED NEW LINE FROM BUTTON: "+button_list[i].getText() +  " TO BUTTON: "+button_list[j].getText());

                }
            }

        }
    }
    /*
    public void displayNextButtonToBeColored



    */


    public void setupButtons() {
        red.setup(red);
        blue.setup(blue);
        green.setup(green);
        yellow.setup(yellow);
        pink.setup(pink);
        turquoise.setup(turquoise);
    }

    public void setOnAction() {
        red.setOnAction(this);
        blue.setOnAction(this);
        green.setOnAction(this);
        yellow.setOnAction(this);
        pink.setOnAction(this);
        turquoise.setOnAction(this);
    }

    public int[][] createMatrix()
    {

        int[][] adj_matrix = new int[numberOfVertices][numberOfVertices];
        int counterOfEdges = 0;
        while (counterOfEdges < numberOfEdges) {
            int n = rand.nextInt(numberOfVertices);
            int m = rand.nextInt(numberOfVertices);

                while(adj_matrix[n][m]==1) {
                    n = rand.nextInt(numberOfVertices);
                    m = rand.nextInt(numberOfVertices);
                }
                if(m!=n) {

                adj_matrix[n][m] = 1;
                adj_matrix[m][n] = 1;
            }else counterOfEdges--;
            counterOfEdges++;
        }
        return adj_matrix;
    }

    public void colorLines(int [][] adj_matrix,int i) {

        int counter = 0;
        for (int j = 0; j < adj_matrix.length; j++) {
            if ((adj_matrix[i][j] == 1 || adj_matrix[j][i] == 1) && i != j) {
                line = new Line();
                line.setStartX(button_list[i].getLayoutX() + 11);
                line.setStartY(button_list[i].getLayoutY() + 11);
                line.setEndY(button_list[j].getLayoutY() + 11);
                line.setEndX(button_list[j].getLayoutX() + 11);
                if (button_list[i].getStyle().equals("-fx-background-color: white;"))
                {
                    line.setStyle("-fx-stroke-width: 3;-fx-stroke: black;");
                } else {
                    String line_style=button_list[i].getStyle().substring(21);
                    line.setStyle("-fx-stroke-width: 3;-fx-stroke:"+line_style);
                }
                layout.getChildren().add(line);
                color_lineList[counter] = line;
                counter++;
            }
        }
    }

    public String[] remove_element(String[] List,int index) {
        String[] augmented_List=new String[List.length-1];
        for(int i=0,k=0;i<List.length;i++)
        {
            if(i==index)
            {
                continue;
            }
            augmented_List[k++]=List[i];
        }
        System.out.println(index+".STYLE LIST REMOVED"+style_list[index]);
        return augmented_List;
    }

    public boolean check_completion() {
        int count=0;
        boolean value = true;
        String[] unaltered_list=new String[style_list.length];
        for (int i = 0; i < matrix.length; i++)
        {
            if (button_list[i].getStyle().equals("-fx-background-color: white;"))
            {
                return false;
            }
        }
        if (value)
        {
            for (int i = 0; i < matrix.length; i++)
            {
                for (int j = 0; j < style_list.length; j++)
                {
                    unaltered_list[j]=style_list[j];
                    if (button_list[i].getStyle().equals(style_list[j]))
                    {
                        style_list=remove_element(style_list,j);
                        count++;
                        System.out.println("COUNT : "+ count);
                    }
                }
            }
            if(count==3) { return true;}
            style_list=unaltered_list;
        }
        return false;
    }



}
