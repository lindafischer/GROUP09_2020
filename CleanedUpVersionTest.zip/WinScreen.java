import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.*;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class WinScreen {
  public WinScreen(Stage someStage, Image backgroundImage, Scene menu) {
    window = someStage;
    background = backgroundImage;
    menuScene = menu;
    width = 100;
    height = 70;
  }
  public void show() {
    StackPane root = new StackPane();
    root.setPrefSize(1050, 600);
    Scene scene = new Scene(root);
    window.setScene(scene);
    ImageView backGroundView = new ImageView(background);
    backGroundView.setFitWidth(1050);
    backGroundView.setFitHeight(600);
    //Win Text
    Text winText = new Text("You found the chromatic number!\n Well done!\n\n\n\n\n\n\n");
    winText.setTextAlignment(TextAlignment.CENTER);
    winText.setFont(Font.font("TimesRoman", FontWeight.BOLD, FontPosture.ITALIC, 50));
    winText.setFill(Color.WHITE);
    winText.setStrokeWidth(2);
    winText.setStroke(Color.BLACK);
    //Home button
    Button homeButton = new Button("Home");
    homeButton.setPrefWidth(width);
    homeButton.setPrefHeight(height);
    double actualX = (scene.getWidth()/2) - width/2;
    double actualY = (scene.getHeight()/2) - height/2;
    homeButton.setLayoutX(actualX);
    homeButton.setLayoutY(actualY);
    homeButton.setOnAction(e -> window.setScene(menuScene));
    root.getChildren().addAll(backGroundView, winText, homeButton);
  }

  private Stage window;
  private Image background;
  private Scene menuScene;
  private double width;
  private double height;
}
