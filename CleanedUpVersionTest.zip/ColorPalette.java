public class ColorPalette {
  public ColorPalette(String[] colors) {
    width = 100;
    height = 100;
    possibleColors = colors;
    buttons = new ColorButton[possibleColors.length];
    int rowNumber = 0;
    int colNumber = 0;
    for(int i = 0; i < possibleColors.length; i++) {
      if(i%4 == 0) {
        rowNumber++;
        colNumber = 1;
      }
      buttons[i] = new ColorButton(colors[i], colNumber * 40, rowNumber*30);
      colNumber++;
    }
  }

  public ColorButton[] getButtons() {
    return buttons;
  }

  private int width;
  private int height;
  private String[] possibleColors;
  private ColorButton[] buttons;
}
