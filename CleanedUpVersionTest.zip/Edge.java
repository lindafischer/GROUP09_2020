import javafx.scene.shape.Line;
public class Edge extends Line {
  public Edge(double x1, double y1, double x2, double y2) {
    super(x1, y1, x2, y2);
  }
}
