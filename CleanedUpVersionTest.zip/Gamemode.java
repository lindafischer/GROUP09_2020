import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import java.util.*;

public class Gamemode {
  public Gamemode(Stage someStage, Scene menu, Image backGroundImage, String title) {
    window = someStage;
    menuScene = menu;
    background = backGroundImage;
    gameTitle = title;
    options = new OptionsView(window, background, menuScene);
  }

  public void run() {
    options.setChild(this);
    options.show();
  }

  public void setGraph(Graph someGraph) {
    g = someGraph;
    chromaticNumber = g.getChromaticNumber();
  }

  public void createGraph(int n, int m) {
    g = new Graph(n, m);
    chromaticNumber = g.getChromaticNumber();
  }

  public void show() {
    gameRoot = new Pane();
    gameRoot.setPrefSize(1050, 600);
    gameScene = new Scene(gameRoot);
    gameRoot.setStyle("-fx-background-color: beige;");
    window.setScene(gameScene);
    helperButtons();
    invalidColor = new Text("Cannot use that color, please pick another one!");
    invalidColor.setLayoutX(200);
    invalidColor.setLayoutY(100);
    noteCompletion = new Text("Please color all vertices first!");
    noteCompletion.setStrokeWidth(4);
    noteCompletion.setLayoutX(1050/2);
    noteCompletion.setLayoutY(70);
    drawGraph();
  }

  public void drawGraph() {
    Random rand = new Random();
    int[][] adj = g.getAdj();
    nodes = new Node[adj.length];
    int m = g.getEdgeNumber();
    int nodeCount = 0;
    Ellipse buttonShape = new Ellipse(30, 30);
    while(nodeCount < adj.length) {
      nodes[nodeCount] = new Node("" + nodeCount, buttonShape);
      double x = 140 + ((gameScene.getWidth()-140) - 140) * rand.nextDouble();
      double y = 140 + ((gameScene.getHeight()-140) - 140) * rand.nextDouble();
      if(checkOverlap(x, y, nodeCount)) {
        nodes[nodeCount].setPosition(x, y);
        nodeCount++;
      }
    }
    edges = new Edge[nodes.length][nodes.length];
    for(int i = 0; i < adj.length; i++) {
      double startX = nodes[i].getX();
      double startY = nodes[i].getY();
      for(int j = i+1; j < adj[i].length; j++) {
        if(adj[i][j] == 1) {
          double endX = nodes[j].getX();
          double endY = nodes[j].getY();
          edges[i][j] = new Edge(startX, startY, endX, endY);
          edges[j][i] = new Edge(startX, startY, endX, endY);
        }
      }
    }
    for(int i = 0; i < edges.length; i++) {
      for(int j = i+1; j < edges[i].length; j++) {
        if(adj[i][j] == 1) {
          gameRoot.getChildren().addAll(edges[i][j]);
        }
      }
    }
    for(int i = 0; i < nodes.length; i++) {
      nodes[i].setOnAction(e -> handleColoring(e.getSource()));
      gameRoot.getChildren().addAll(nodes[i]);
    }
  }

  public void handleColoring(Object eventSource) {
    if(gameRoot.getChildren().contains(invalidColor)) {
      gameRoot.getChildren().remove(invalidColor);
    }
    Node selectedNode = (Node) eventSource;
    int[][] adj = g.getAdj();
    //Reset the lines
    for(int i = 0; i < adj.length; i++) {
      for(int j = i+1; j < adj[i].length; j++) {
        if(adj[i][j] == 1) {
          edges[i][j].setStrokeWidth(1);
          edges[j][i].setStrokeWidth(1);
        }
      }
    }
    //And highlight the currently chosen lines
    int k = Integer.parseInt(selectedNode.getText());
    for(int j = 0; j < edges[k].length; j++) {
      if(adj[k][j] == 1) {
        edges[k][j].setStrokeWidth(4);
        edges[j][k].setStrokeWidth(4);
      }
    }
    ColorButton[] colorButtons = possibleColors.getButtons();
    for(int i = 0; i < colorButtons.length; i++) {
      gameRoot.getChildren().remove(colorButtons[i]);
    }
    for(int i = 0; i < colorButtons.length; i++) {
      String tmpColor = colorButtons[i].getColor();
      colorButtons[i].setOnAction(e -> setNodeColor(tmpColor, selectedNode));
      gameRoot.getChildren().add(colorButtons[i]);
    }
  }

  public void setNodeColor(String c, Node node) {
    if(gameRoot.getChildren().contains(invalidColor)) {
      gameRoot.getChildren().remove(invalidColor);
    }
    if(checkColoring(c, node)) {
      node.setColor(c);
      ColorButton[] colorButtons = possibleColors.getButtons();
    }
    else {
      gameRoot.getChildren().add(invalidColor);
    }
  }

  public boolean checkColoring(String c, Node node) {
    int[][] adj = g.getAdj();
    int i = Integer.parseInt(node.getText());
    for(int j = 0; j < adj[i].length; j++) {
      if(adj[i][j] == 1 && nodes[j].getColor().equals(c)) {
        return false;
      }
    }
    return true;
  }

  public boolean checkOverlap(double x, double y, int currI) {
    for(int i = 0; i < currI; i++) {
      if((Math.abs(x - nodes[i].getX()) < 40) && (Math.abs(y - nodes[i].getY()) < 40)) {
        return false;
      }
    }
    return true;
  }

  public boolean checkCompletion() {
    for(int i = 0; i < nodes.length; i++) {
      if(nodes[i].getColor().equals("white")) {
        return false;
      }
    }
    return true;
  }

  public void submit() {
    if(checkCompletion()) {
      String[] colors = new String[nodes.length];
      for(int i = 0; i < nodes.length; i++) {
        colors[i] = nodes[i].getColor();
      }
      Arrays.sort(colors);
      String prevColor = "";
      int colorCount = 0;
      for(int i = 0; i < colors.length; i++) {
        if(!colors[i].equals(prevColor)) {
          colorCount++;
          prevColor = colors[i];
        }
      }
      System.out.println(colorCount);
      if(colorCount == chromaticNumber) {
        WinScreen win = new WinScreen(window, background, menuScene);
        win.show();
      }
    }
    else{
      if(!gameRoot.getChildren().contains(noteCompletion)) {
        gameRoot.getChildren().add(noteCompletion);
      }
    }
  }

  public String getTitle() {
    return gameTitle;
  }

  public void helperButtons() {
    //Quit button
    Button quitButton = new Button("Quit");
    quitButton.setLayoutX(gameScene.getWidth()-100);
    quitButton.setLayoutY(gameScene.getHeight()-40);
    quitButton.setOnAction(e -> System.exit(0));
    //Submit button
    Button submitButton = new Button("Submit your answer!");
    submitButton.setLayoutX(gameScene.getWidth()-150);
    submitButton.setLayoutY(gameScene.getHeight()-580);
    submitButton.setOnAction(e -> submit());
    //New Color button
    Button newColorButton = new Button("Get a new color!");
    newColorButton.setLayoutX(gameScene.getWidth()-300);
    newColorButton.setLayoutY(gameScene.getHeight()-580);
    //Add the buttons
    gameRoot.getChildren().addAll(quitButton, submitButton, newColorButton);
  }

  public Stage window;
  public Scene menuScene;
  public Image background;
  public OptionsView options;
  public Graph g;
  public Pane gameRoot;
  public Scene gameScene;
  public Node[] nodes;
  public Edge[][] edges;
  public String[] colors = {"red", "green", "blue"};
  public ColorPalette possibleColors = new ColorPalette(colors);
  public Text invalidColor;
  public Text noteCompletion;
  public int chromaticNumber;
  public String gameTitle;
}
