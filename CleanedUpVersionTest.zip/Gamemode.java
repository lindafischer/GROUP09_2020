import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import java.util.*;

public class Gamemode {
  public Gamemode(Stage someStage, Scene menu, Image backGroundImage) {
    window = someStage;
    menuScene = menu;
    background = backGroundImage;
    options = new OptionsView(window, background, menuScene);
  }

  public void run() {
    options.setChild(this);
    options.show();
  }

  public void setGraph(Graph someGraph) {
    g = someGraph;
  }

  public void createGraph(int n, int m) {
    g = new Graph(n, m);
  }

  public void show() {
    gameRoot = new Pane();
    gameRoot.setPrefSize(1050, 600);
    gameScene = new Scene(gameRoot);
    gameRoot.setStyle("-fx-background-color: beige;");
    window.setScene(gameScene);
    helperButtons();
    drawGraph();
  }

  public void drawGraph() {
    Random rand = new Random();
    int[][] adj = g.getAdj();
    nodes = new Node[adj.length];
    int m = g.getEdgeNumber();
    int nodeCount = 0;
    Ellipse buttonShape = new Ellipse(30, 30);
    while(nodeCount < adj.length) {
      nodes[nodeCount] = new Node("" + nodeCount, buttonShape);
      double x = 140 + ((gameScene.getWidth()-140) - 140) * rand.nextDouble();
      double y = 140 + ((gameScene.getHeight()-140) - 140) * rand.nextDouble();
      if(checkOverlap(x, y, nodeCount)) {
        nodes[nodeCount].setPosition(x, y);
        nodeCount++;
      }
    }
    int k = 0;
    Edge[] edges = new Edge[g.getEdgeNumber()];
    for(int i = 0; i < adj.length; i++) {
      System.out.println(Arrays.toString(adj[i]));
      for(int j = i+1; j < adj[i].length; j++) {
        if(adj[i][j] == 1) {
          double startX = nodes[i].getX();
          double startY = nodes[i].getY();
          double endX = nodes[j].getX();
          double endY = nodes[j].getY();
          edges[k] = new Edge(startX, startY, endX, endY);
          k++;
        }
      }
    }
    for(int i = 0; i < edges.length; i++) {
      gameRoot.getChildren().addAll(edges[i]);
    }
    for(int i = 0; i < nodes.length; i++) {
      gameRoot.getChildren().addAll(nodes[i]);
    }
  }

  public boolean checkOverlap(double x, double y, int currI) {
    for(int i = 0; i < currI; i++) {
      if((Math.abs(x - nodes[i].getX()) < 40) && (Math.abs(y - nodes[i].getY()) < 40)) {
        return false;
      }
    }
    return true;
  }

  public void helperButtons() {
    //Quit button
    Button quitButton = new Button("Quit");
    quitButton.setLayoutX(gameScene.getWidth()-100);
    quitButton.setLayoutY(gameScene.getHeight()-40);
    quitButton.setOnAction(e -> System.exit(0));
    //Submit button
    Button submitButton = new Button("Submit your answer!");
    submitButton.setLayoutX(gameScene.getWidth()-150);
    submitButton.setLayoutY(gameScene.getHeight()-580);;
    //New Color button
    Button newColorButton = new Button("Get a new color!");
    newColorButton.setLayoutX(gameScene.getWidth()-300);
    newColorButton.setLayoutY(gameScene.getHeight()-580);
    //Add the buttons
    gameRoot.getChildren().addAll(quitButton, submitButton, newColorButton);
  }
  public Stage window;
  public Scene menuScene;
  public Image background;
  public OptionsView options;
  public Graph g;
  public Pane gameRoot;
  public Scene gameScene;
  public Node[] nodes;
}
