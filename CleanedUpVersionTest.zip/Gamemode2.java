import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import java.util.*;

public class Gamemode2 extends Gamemode {
  public Gamemode2(Stage someStage, Scene menu, Image backgroundImage, String title) {
    super(someStage, menu, backgroundImage, title);
    options.setTitleX(300);
  }

  public void show() {
    super.show();
    timer = new Timer(200, 100, window, menuScene, background, "Game Over!\nYou were not fast enough sadly!\n\n\n\n");
    gameRoot.getChildren().add(timer);
    timer.start();
  }

  public int computeScore(int c) {
    long timeLeft = 300000 - timer.getTime();
    int colorDifference = c - boundArray[1];
    double tmpScore = timeLeft;
    if(colorDifference > 0) {
      tmpScore += (300000 / colorDifference);
    }
    else {
      tmpScore += 300000;
    }
    int normalizedScore = (int) ((tmpScore/600000.0) * 100);
    return normalizedScore;
  }

  @Override
  public void submit() {
    if(checkCompletion()) {
      int colorCount = countUserColors();
      if(task != null && !task.isCancelled()) {
        task.cancel();
        timer.stop();
        WinScreen win = new WinScreen(window, background, menuScene, "Congratulations!\nYou used " + colorCount + " colors\nOur upper bound: " + boundArray[1] + "\nYour time: " + timer.timeParser(timer.getTime()) + "\nYour score: " + computeScore(colorCount) + "\n\n\n\n\n\n\n\n");
        win.show();
      }
      if(colorCount == chromaticNumber) {
        timer.stop();
        WinScreen win = new WinScreen(window, background, menuScene, "Congratulations!\nYou used " + colorCount + " colors\nOur upper bound: " + boundArray[1] + "\nYour time: " + timer.timeParser(timer.getTime()) + "\nYou found the chromatic number! You receive 10 bonus points!\nYour score: " + (computeScore(colorCount) + 10) + "\n\n\n\n\n\n\n\n");
        win.show();
      }
      else if(colorCount > chromaticNumber) {
        timer.stop();
        WinScreen win = new WinScreen(window, background, menuScene, "Congratulations!\nYou used " + colorCount + " colors.\nOur upper bound: " + boundArray[1] + "\nYour time: " + timer.timeParser(timer.getTime()) + "\nYour score: " + computeScore(colorCount) + "\n\n\n\n\n\n\n\n");
        win.show();
      }
    }
    else{
      if(!gameRoot.getChildren().contains(noteCompletion)) {
        gameRoot.getChildren().add(noteCompletion);
      }
    }
  }
  private Timer timer;
}
