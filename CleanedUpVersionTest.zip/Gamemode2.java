import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import java.util.*;

public class Gamemode2 extends Gamemode {
  public Gamemode2(Stage someStage, Scene menu, Image backgroundImage, String title) {
    super(someStage, menu, backgroundImage, title);
    options.setTitleX(300);
  }

  public void show() {
    super.show();
    timer = new Timer(200, 100, window, menuScene, background, "Game Over!\nYou were not fast enough sadly!\n\n\n\n");
    gameRoot.getChildren().add(timer);
    timer.start();
  }

  @Override
  public void submit() {
    if(checkCompletion()) {
      if(task != null && !task.isCancelled()) {
        task.cancel();
        WinScreen win = new WinScreen(window, background, menuScene, "Congratulations!\nYou beat our bruteforcing algorithm!\n Our lower bound: " + boundArray[0] + "\nOur upper bound: " + boundArray[1] +"\n\n\n\n\n\n\n");
        win.show();
      }
      String[] colors = new String[nodes.length];
      for(int i = 0; i < nodes.length; i++) {
        colors[i] = nodes[i].getColor();
      }
      Arrays.sort(colors);
      String prevColor = "";
      int colorCount = 0;
      for(int i = 0; i < colors.length; i++) {
        if(!colors[i].equals(prevColor)) {
          colorCount++;
          prevColor = colors[i];
        }
      }
      if(colorCount == chromaticNumber) {
        timer.stop();
        WinScreen win = new WinScreen(window, background, menuScene, "You found the chromatic number!\n Well done!\n\n\n\n\n\n\n");
        win.show();
      }
      else if(colorCount > chromaticNumber) {
        gameRoot.getChildren().add(tooManyColorsNote);
      }
    }
    else{
      if(!gameRoot.getChildren().contains(noteCompletion)) {
        gameRoot.getChildren().add(noteCompletion);
      }
    }
  }
  private Timer timer;
}
