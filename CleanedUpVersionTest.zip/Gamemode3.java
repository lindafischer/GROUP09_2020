import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import java.util.*;
import javafx.concurrent.*;

public class Gamemode3 extends Gamemode {
  public Gamemode3(Stage someStage, Scene menu, Image background, String title) {
    super(someStage, menu, background, title);
  }

  public void show() {
    super.show();
    order = new int[nodes.length];
    for(int i = 0; i < order.length; i++) {
      order[i] = Integer.parseInt(nodes[i].getText());
    }
    Random rand = new Random();
    for(int i = 0; i < order.length; i++) {
      int randomInt = rand.nextInt(order.length - i) + i;
      int tmp = order[i];
      order[i] = order[randomInt];
      order[randomInt] = tmp;
    }
    for(int i = 0; i < nodes.length; i++) {
      if(Integer.parseInt(nodes[i].getText()) != order[nodeIterator]) {
        nodes[i].setDisable(true);
      }
      else {
        nodes[i].setDisable(false);
        nodes[i].setStyle("-fx-border-color: black; -fx-border-width: 2 2 2 2; -fx-background-color: white;");
        selectedNode = nodes[i];
      }
    }

    Text orderNote = new Text("Please color the selected node!");
    orderNote.setFont(Font.font("TimesRoman", FontWeight.BOLD, FontPosture.ITALIC, 24));
    orderNote.setLayoutX(300);
    orderNote.setLayoutY(70);
    gameRoot.getChildren().add(orderNote);
  }
  @Override
  public void setNodeColor(String c, Node node) {
    super.setNodeColor(c, node);
    if(!node.getColor().equals("white")) {
      nodeIterator++;
      if(nodeIterator >= nodes.length) {
        nodeIterator--;
        nodes[order[nodeIterator]].setDisable(true);
      }
      else {
        for(int i = 0; i < nodes.length; i++) {
          if(Integer.parseInt(nodes[i].getText()) != order[nodeIterator]) {
            nodes[i].setDisable(true);
          }
          else {
            nodes[i].setDisable(false);
            nodes[i].setStyle("-fx-border-color: black; -fx-border-width: 2 2 2 2; -fx-background-color: white;");
          }
        }
      }
    }
    selectedNode = nodes[order[nodeIterator]];
  }

  private int[] order;
  private int nodeIterator;
}
