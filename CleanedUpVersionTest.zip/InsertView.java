import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.*;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;


public class InsertView {
  public InsertView(Stage someStage, Image backgroundImage, Scene options, Gamemode gmChild) {
    window = someStage;
    background = backgroundImage;
    optionsScene = options;
    gamemodeChild = gmChild;
  }

  public void show() {
    root = new Pane();
    root.setPrefSize(1050, 600);
    Scene scene = new Scene(root);
    ImageView backGroundView = new ImageView(background);
    backGroundView.setFitWidth(1050);
    backGroundView.setFitHeight(600);
    //Back button
    Image imageback = new Image("assets\\back.jpg");
    ImageView viewback = new ImageView(imageback);
    viewback.setFitWidth(150);
    viewback.setFitHeight(80);
    Button back = new Button("", viewback);
    back.setLayoutX(800);
    back.setLayoutY(15);
    window.setScene(scene);
    back.setOnAction(e -> window.setScene(optionsScene));
    //Creating the text fields
    v_textField = new TextField();
    v_textField.setText("...");
    Text v_text = new Text("Input vertix number: ");
    v_textField = new TextField();
    v_textField.setText("");
    //And the submit button
    Button v_button = new Button("Submit");
    Text e_text = new Text("Input edges number: ");
    e_textField = new TextField();
    e_textField.setText("...");
    Text text = new Text("Input vertices number: ");
    e_textField = new TextField();
    e_textField.setText("");
    //Initialize the note to provide senseful input
    senseNote = new Text("Please input a configuration that makes sense!\n(Not 1 node and 1 vertex or 2 nodes and 2 vertices,\n not 0 vertices,...)");
    senseNote.setLayoutX(scene.getWidth()/2);
    senseNote.setLayoutY(scene.getHeight()/2);
    senseNote.setStrokeWidth(4);
    //Positioning the items
    setCoords(v_textField,v_button,v_text,e_textField,e_text);

    //Handling the submit button
    v_button.setOnAction(e -> parseInput());
    //And adding them
    root.getChildren().addAll(backGroundView,v_textField,v_button,v_text, back);
    root.getChildren().addAll(e_text,e_textField);
  }

  public void setCoords(TextField v_textField,Button v_button,Text v_text, TextField e_textField,Text e_text) {
    v_textField.setLayoutX(100);
    v_textField.setLayoutY(100);
    v_button.setLayoutX(270);
    v_button.setLayoutY(150);
    v_text.setLayoutX(100);
    v_text.setLayoutY(90);
    e_textField.setLayoutX(100);
    e_textField.setLayoutY(200);
    e_text.setLayoutX(100);
    e_text.setLayoutY(190);
  }

  public void parseInput() {
    int n = Integer.parseInt(v_textField.getText());
    int m = Integer.parseInt(e_textField.getText());
    if((n == 1 || n == 2) && (n <= m) || (n == 0)) {
      if(!root.getChildren().contains(senseNote)) {
        root.getChildren().add(senseNote);
      }
    }
    else {
      gamemodeChild.createGraph(n, m);
      gamemodeChild.show();
    }
  }

  private Stage window;
  private Image background;
  private Scene optionsScene;
  private Gamemode gamemodeChild;
  private TextField e_textField;
  private TextField v_textField;
  private Text senseNote;
  private Pane root;
}
