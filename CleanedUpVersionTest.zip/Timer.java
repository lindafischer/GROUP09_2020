import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import java.util.*;

import javafx.application.Platform;
import javafx.scene.control.Label;

public class Timer extends Label {

	Long time;
	Boolean processing;
	private WinScreen gameOver;

	public Timer(double xPos, double yPos, Stage someStage, Scene menu, Image background, String title) {
		setLayoutX(xPos);
		setLayoutY(yPos);
		setFont(Font.font("TimesRoman", FontWeight.BOLD, FontPosture.ITALIC, 28));
		gameOver = new WinScreen(someStage, background, menu, title);
	}

	public void start() {
		time = 0L;
		processing = true;

		buildThread().start();
	}

	public void stop() {
		processing = false;
	}

	public Thread buildThread() {
		return new Thread(() -> {
			while (processing) {
				if(time >= 300000){
					Platform.runLater(() -> {
						setTextFill(Color.RED);
						gameOver.show();
					});
					processing = false;
				}
				Platform.runLater(() -> setText(timeParser(time)));
				try {
					Thread.sleep(1000);
					time = time + 1000;
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			}
		});
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public Boolean getProcessing() {
		return processing;
	}

	public void setProcessing(Boolean processing) {
		this.processing = processing;
	}

	public static String timeParser(Long time) {
		Double t = time.doubleValue();
		Double msecPerMinute = 1000.0 * 60.0;
		Double msecPerHour = msecPerMinute * 60.0;

		Double hours = Math.floor(t / msecPerHour);
		t = t - (hours * msecPerHour);
		Double minutes = Math.floor(t / msecPerMinute);
		t = t - (minutes * msecPerMinute);

		Double seconds = Math.floor(t / 1000);

		return (hours < 10 ? "0" : "") + hours.intValue() + ":" + (minutes < 10 ? "0" : "") + minutes.intValue() + ":"
				+ (seconds < 10 ? "0" : "") + seconds.intValue();
	}
}
