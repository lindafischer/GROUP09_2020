import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class OptionsView {
  public OptionsView(Stage someStage, Image backgroundImage, Scene menu) {
    background = backgroundImage;
    menuScene = menu;
    window = someStage;
  }

  public void setChild(Gamemode gamemodeChild) {
    child = gamemodeChild;
  }

  public void show() {
    Pane root = new Pane();
    root.setPrefSize(1050, 600);
    scene = new Scene(root);
    ImageView backGroundView = new ImageView(background);
    backGroundView.setFitWidth(1050);
    backGroundView.setFitHeight(600);
    //Back button
    Image imageback = new Image("assets\\back.jpg");
    ImageView viewback = new ImageView(imageback);
    viewback.setFitWidth(150);
    viewback.setFitHeight(80);
    Button back = new Button("", viewback);
    back.setLayoutX(800);
    back.setLayoutY(15);
    window.setScene(scene);
    back.setOnAction(e -> window.setScene(menuScene));
    //Title
    Text randomorder = new Text (child.getTitle());
    randomorder.setTranslateX(320);
    randomorder.setTranslateY(200);
    randomorder.setFont(Font.font("TimesRoman", FontWeight.BOLD, FontPosture.ITALIC, 60));
    randomorder.setFill(Color.WHITE);
    randomorder.setStrokeWidth(2);
    randomorder.setStroke(Color.BLACK);
    //Insert button
    Image insertImage = new Image("assets\\insert.jpg");
    ImageView insertView = new ImageView(insertImage);
    insertView.setFitWidth(600);
    insertView.setFitHeight(80);
    Button insert = new Button(" ", insertView);
    insert.setLayoutX(230);
    insert.setLayoutY(250);
    insert.setOnAction(e -> insert());
    //Upload button
    Image uploadImage = new Image("assets\\upload.jpg");
    ImageView uploadView = new ImageView(uploadImage);
    uploadView.setFitWidth(325);
    uploadView.setFitHeight(60);
    Button upload = new Button(" ", uploadView);
    upload.setLayoutX(350);
    upload.setLayoutY(380);
    upload.setOnAction(e -> upload());
    root.getChildren().addAll(backGroundView, back, insert, upload, randomorder);
  }

  private void insert() {
    InsertView insertView = new InsertView(window, background, scene, child);
    insertView.show();
  }

  private void upload() {
    child.setGraph(Uploader.getGraphFromFile());
    child.show();
  }
  private Stage window;
  private Scene menuScene;
  private Image background;
  private Gamemode child;
  private Scene scene;
}
