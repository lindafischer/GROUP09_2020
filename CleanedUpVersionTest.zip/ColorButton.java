import javafx.scene.control.Button;
public class ColorButton extends Button {
  public ColorButton(String c, int xPos, int yPos) {
    super("");
    setLayoutX(xPos);
    setLayoutY(yPos);
    setStyle(color + c + ";");
    stringColor = c;
  }

  public String getColor() {
    return stringColor;
  }
  private String stringColor;
  private String color = "-fx-background-color: ";
}
