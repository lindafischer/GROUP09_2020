import java.util.Random;

public class Graph {
  private int[][] adj;
  private Random rand = new Random();
  public Graph(ColEdge[] colEdges, int n, int m) {
    adj = HelperFunctions.getAdjacencyMatrix(colEdges, m, n);
    col = colEdges;
    edgeNumber = m;
    vertexNumber = n;
  }

  public Graph(int n, int m) {
    adj = new int[n][n];
    vertexNumber = n;
    edgeNumber = m;
    int edgeCount = 0;
    while(edgeCount < edgeNumber) {
      int i = (int) (Math.random() * n);
      int j = (int) (Math.random() * n);
      if(i != j && adj[i][j] != 1) {
        adj[i][j] = 1;
        adj[j][i] = 1;
        edgeCount++;
      }
    }
    col = computeColEdges();
  }

  public ColEdge[] computeColEdges() {
    ColEdge[] colEdges = new ColEdge[edgeNumber];
    int counter = 0;
    for(int i = 0; i < adj.length; i++) {
      for(int j = i+1; j < adj[i].length; j++) {
        if(adj[i][j] == 1) {
          colEdges[counter] = new ColEdge();
          colEdges[counter].u = i;
          colEdges[counter].v = j;
          counter++;
        }
      }
    }
    return colEdges;
  }

  public ColEdge[] getColEdgeArray() {
    return col;
  }

  public int[][] getAdj() {
    return adj;
  }

  public int getVertexNumber() {
    return vertexNumber;
  }

  public int getEdgeNumber() {
    return edgeNumber;
  }

  public int getChromaticNumber() {
    return chromaticNumber;
  }

  private int vertexNumber;
  private int edgeNumber;
  private int chromaticNumber;
  private ColEdge[] col;
}
