import java.util.Random;

public class Graph {
  private int[][] adj;
  private Random rand = new Random();
  public Graph(ColEdge[] colEdges, int n, int m) {
    adj = HelperFunctions.getAdjacencyMatrix(colEdges, m, n);
    chromaticNumber = HelperFunctions.getChromaticNumber(adj, n, m);
  }

  public Graph(int n, int m) {
    adj = new int[n][n];
    vertexNumber = n;
    edgeNumber = m;
    int edgeCount = 0;
    while(edgeCount < edgeNumber) {
      int i = (int) (Math.random() * n);
      int j = (int) (Math.random() * n);
      if(i != j && adj[i][j] != 1) {
        adj[i][j] = 1;
        adj[j][i] = 1;
        edgeCount++;
      }
    }
    chromaticNumber = HelperFunctions.getChromaticNumber(adj, n, m);
  }

  public int[][] getAdj() {
    return adj;
  }

  public int getVertexNumber() {
    return vertexNumber;
  }

  public int getEdgeNumber() {
    return edgeNumber;
  }

  public int getChromaticNumber() {
    return chromaticNumber;
  }

  private int vertexNumber;
  private int edgeNumber;
  private int chromaticNumber;
}
