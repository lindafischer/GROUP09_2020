import java.io.IOException;
import java.io.InputStream;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;

import javafx.application.*;
import javafx.stage.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.*;
import javafx.scene.control.Label;
import javafx.scene.shape.*;
import javafx.scene.control.Button;

import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;

public class Node extends Button {
  public Node(String title, Shape buttonShape) {
    super(title);
    setPrefWidth(30);
    setPrefHeight(30);
    setShape(buttonShape);
  }
  public void setColor(String c) {
    String tmpColor = color + c + "; ";
    setStyle(tmpColor);
  }
  public void setPosition(double x, double y) {
    super.setLayoutX(x);
    super.setLayoutY(y);
    xPos = x;
    yPos = y;
    Bounds bounds = getBoundsInParent();
  }

  public double getX() {
    return xPos + 30/2;
  }
  public double getY() {
    return yPos + 30/2;
  }
  private String color = "-fx-background-color: ";
  private double xPos;
  private double yPos;
}
